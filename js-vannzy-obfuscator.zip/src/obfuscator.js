const acorn = require('acorn');
const escodegen = require('escodegen');

class Obfuscator {
  constructor() {
    this.variableMap = new Map();
  }

  parseCode(code) {
    return acorn.parse(code, { ecmaVersion: 2020 });
  }

  generateRandomName() {
    return '_' + Math.random().toString(36).substring(2, 9);
  }

  obfuscateNames(ast) {
    const traverse = (node) => {
      if (node.type === 'VariableDeclarator' || node.type === 'FunctionDeclaration') {
        if (!this.variableMap.has(node.id.name)) {
          this.variableMap.set(node.id.name, this.generateRandomName());
        }
        node.id.name = this.variableMap.get(node.id.name);
      }

      if (node.type === 'Identifier' && this.variableMap.has(node.name)) {
        node.name = this.variableMap.get(node.name);
      }

      for (const key in node) {
        if (node[key] && typeof node[key] === 'object') {
          traverse(node[key]);
        }
      }
    };

    traverse(ast);
    return ast;
  }

  generateCode(ast) {
    return escodegen.generate(ast);
  }

  obfuscate(code) {
    let obfuscatedCode = code;
    const ast = this.parseCode(obfuscatedCode);

    const obfuscatedAst = this.obfuscateNames(ast);
    obfuscatedCode = this.generateCode(obfuscatedAst);

    obfuscatedCode = this.insertDeadCode(obfuscatedCode);
    obfuscatedCode = this.obfuscateStrings(obfuscatedCode);

    return obfuscatedCode;
  }

  insertDeadCode(code) {
    return code + "\nlet _deadCode = 12345; _deadCode = _deadCode * 0;";
  }

  encryptString(str) {
    return Buffer.from(str).toString('base64');
  }

  obfuscateStrings(code) {
    return code.replace(/'([^']+)'/g, (match, p1) => {
      return `'${this.encryptString(p1)}'`;
    });
  }
}

module.exports = Obfuscator;
